ITI0302-2021 Veebiprojekt back-end repo 
Members: Andero Raava, Liisi Nõojärv ja Karl Hans Lorenz Ernits
Mentor: Valeri Andrejev

###JUST TESTING

How to start the application

1. If you open up project you should navigate to pom.xml to build the project.
2. To start up the project run the Application class.
3. Now open front-end repo in another window.
4. Open terminal and navigate to /vet-clinic.
5. In the terminal type yarn start
6. The accesport to open project is localhost:3000


Congrats you have succesfully ran the application. Feel free to navigate around and explore.


How to use tests:
Right click on Tests file(green one), and run all tests.
