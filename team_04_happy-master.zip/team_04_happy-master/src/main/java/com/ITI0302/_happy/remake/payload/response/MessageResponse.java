package com.ITI0302._happy.remake.payload.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter @AllArgsConstructor

public class MessageResponse {
    private String message;
}
