package com.ITI0302._happy.remake.payload.request;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LoginRequest {
//    @NotBlank
    private String username;

//    @NotBlank
    private String password;
}
