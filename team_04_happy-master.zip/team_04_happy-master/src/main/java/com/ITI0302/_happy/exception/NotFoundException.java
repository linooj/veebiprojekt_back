package com.ITI0302._happy.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {super(message);}
}
